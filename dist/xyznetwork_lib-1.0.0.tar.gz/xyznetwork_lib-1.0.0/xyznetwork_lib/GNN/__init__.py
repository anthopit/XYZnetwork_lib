import GNN.run
import GNN.loss
import GNN.data
import GNN.model
import GNN.utils
from GNN.run import *
from GNN.loss import *
from GNN.data import *
from GNN.model import *
from GNN.utils import *