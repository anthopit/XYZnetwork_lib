import GNN.data
from GNN.data import *
import GNN.loss
from GNN.loss import *
import GNN.model
from GNN.model import *
import GNN.run
from GNN.run import *
import GNN.utils
from GNN.utils import *
